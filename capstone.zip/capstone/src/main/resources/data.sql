INSERT INTO todo_table (todo_description, todo_user, todo_date, todo_status, todo_priority)
VALUES("clean up the barracks", "ACTIVE", CURDATE(), 1, 2);
INSERT INTO todo_table (todo_description, todo_user, todo_date,  todo_status, todo_priority)
VALUES("clean up your bunk", "ACTIVE", CURDATE(),  0, 1);
INSERT INTO todo_table (todo_description, todo_user, todo_date, todo_status, todo_priority)
VALUES("pick up trash", "RESERVE", CURDATE(),  1, 1);
INSERT INTO todo_table (todo_description, todo_user, todo_date, todo_status, todo_priority)
VALUES("complete your physical training", "RESERVE", CURDATE(),  0, 3);
INSERT INTO todo_table (todo_description, todo_user, todo_date, todo_status, todo_priority)
VALUES("complete scheduling paperwork", "OFFICER", CURDATE(),  1, 2);
INSERT INTO todo_table (todo_description, todo_user, todo_date, todo_status, todo_priority)
VALUES("complete the todo tasks for reserves", "OFFICER", CURDATE(),  0, 1);